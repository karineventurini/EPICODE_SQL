#CREARE IL DATABASE E LE TABELLE
CREATE DATABASE toysgroup;
USE toysgroup;
SHOW databases;

CREATE TABLE Category (
	Category_ID INT PRIMARY KEY AUTO_INCREMENT,
    CategoryName VARCHAR (150) NOT NULL
    );

CREATE TABLE Product (
	Product_ID INT PRIMARY KEY AUTO_INCREMENT,
    ProductName VARCHAR (150) NOT NULL,
    ListPrice DECIMAL (10,2),
    Category_ID INT,
    FOREIGN KEY (Category_ID) REFERENCES Category (Category_ID)
    );
    
CREATE TABLE Region (
	Region_ID INT PRIMARY KEY AUTO_INCREMENT,
    RegionName VARCHAR (150) NOT NULL
    );
    
CREATE TABLE Country (
	Country_ID INT PRIMARY KEY AUTO_INCREMENT,
    CountryName VARCHAR (150) NOT NULL,
    Region_ID INT,
    FOREIGN KEY (rEGION_id) REFERENCES Region (Region_ID)
    );
    
CREATE TABLE Sales (
	Sale_ID INT PRIMARY KEY AUTO_INCREMENT,
    SaleDate DATE NOT NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL (10,2) NOT NULL,
    Product_ID INT NOT NULL,
    Country_ID INT NOT NULL,
    FOREIGN KEY (Product_ID) REFERENCES Product (Product_ID),
    FOREIGN KEY (Country_ID) REFERENCES Country (Country_ID)
    );
    
# ADESSO DEVO POPOLARE LE TABELLE

# TABELLA CATEGORY

INSERT INTO Category (CategoryName)
VALUES 
('Dolls'),
('Games'),
('Bike'),
('Building Sets');    

SELECT * 
FROM Category;


# TABELLA PRODUCT

INSERT INTO Product (ProductName, ListPrice, Category_ID)
VALUES
('Fashion Doll', 25.9, 1),
('Baby Doll', 19.5, 1),
('Chess Classic', 15.00, 2),
('Uno Card Game', 9.90, 2),
('Kids Bike 12"', 89.90, 3),
('Mountain Bike Mini', 120.00, 3),
('Building Blocks 200 pcs', 39.00, 4),
('Construction Crane Set', 59.00, 4),
('Puzzle Farm Animals', 14.50, 2),
('Mini Dollhouse', 35.00, 1),
('Barbie Doll', 30.00,1);

SELECT *
FROM Product;


# TABELLA REGION

INSERT INTO Region (RegionName)
VALUES
('WestEurope'),
('SouthEurope'),
('NorthAmerica'),
('AsiaPasific'),
('SouthAmerica');

SELECT *
FROM Region;


# TABELLA COUNTRY

INSERT INTO Country (CountryName, Region_ID)
VALUES
('Italy', 2),
( 'France', 1),
('Germany', 1),
('Spain', 2),
('USA', 3),
('Canada', 3),
('Brazil', 5),
('Argentina', 5),
('Japan', 4),
('Australia', 4);

SELECT *
FROM Country;


# TABELLA SALES

INSERT INTO Sales (SaleDate, Quantity, UnitPrice, Product_ID, Country_ID)
VALUES
('2024-01-10', 3, 25.90, 1, 1),   -- Baby Doll in Italy
('2024-01-12', 2, 19.50, 2, 2),   -- Baby Dool in France
('2024-02-01', 1, 15.00, 3, 3),   -- Chess Classic in Germany
('2024-02-05', 5, 9.90, 4, 4),    -- Uno Card Game in Spain
('2024-03-10', 2, 89.00, 5, 5),   -- Kids Bike 12” in USA
('2024-03-12', 1,120.00, 6, 6),   -- Mountain Bike Mini in Canada
('2024-04-20', 4, 39.00, 7, 7),   -- Building Blocks 200 pcs in Brazil
('2025-04-25', 3, 59.00, 8, 8),   -- Construction Crane Set in Argentina
('2025-05-10', 6, 14.50, 9, 9),   -- Puzzle Farm Animals in Japan
('2025-05-15', 2, 35.00,10,10),   -- Mini Dollhouse in Australia
('2025-01-10', 3, 25.90, 1, 1);   -- Baby Doll in Italy

SELECT *
FROM Sales;

# INIZIO TASK 4
-- 1 - CONTROLLO DELLE PK

# TABELLA CATEGORY
# CONTROLLO DUPLICATI, NESSUNA RIGHA = NESSUN DUPLICATO
# CONTROLLO NULL, NESSUNA RIGA = NESSUN VALORE MANCANTE

SELECT Category_ID, COUNT(*) AS Conteggio
FROM CAtegory
GROUP BY Category_ID
HAVING COUNT(*) > 1;

SELECT *
FROM Category
WHERE Category_ID IS NULL;

# TABELLA PRODUCT
# CONTROLLO DUPLICATI, NESSUNA RIGHA = NESSUN DUPLICATO
# CONTROLLO NULL, NESSUNA RIGA = NESSUN VALORE MANCANTE

SELECT Product_ID, COUNT(*) AS Conteggio
FROM Product
GROUP BY Product_ID
HAVING COUNT(*) > 1;

SELECT *
FROM Product
WHERE Product_ID IS NULL;

# TABELLA REGION
# CONTROLLO DUPLICATI, NESSUNA RIGHA = NESSUN DUPLICATO
# CONTROLLO NULL, NESSUNA RIGA = NESSUN VALORE MANCANTE

SELECT Region_ID, COUNT(*) AS Conteggio
FROM Region
GROUP BY Region_ID
HAVING COUNT(*) > 1;

SELECT *
FROM Region
WHERE Region_ID IS NULL;

# TABELLA COUNTRY
# CONTROLLO DUPLICATI, NESSUNA RIGHA = NESSUN DUPLICATO
# CONTROLLO NULL, NESSUNA RIGA = NESSUN VALORE MANCANTE

SELECT Country_ID, COUNT(*) AS Conteggio
FROM Country
GROUP BY Country_ID
HAVING COUNT(*) > 1;

SELECT *
FROM Country
WHERE Country_ID IS NULL;

# TABELLA SALES
# CONTROLLO DUPLICATI, NESSUNA RIGHA = NESSUN DUPLICATO
# CONTROLLO NULL, NESSUNA RIGA = NESSUN VALORE MANCANTE

SELECT Sale_ID, COUNT(*) AS Conteggio
FROM Sales
GROUP BY Sale_ID
HAVING COUNT(*) > 1;

SELECT *
FROM Sales
WHERE Sale_ID IS NULL;

-- 2 - ESPORRE TRANSAZIONI, PIù DI 180 GG DALLA VENDITA - CAMPO BOOLEANO 1= VERO (PIU DI 180GG) E 0= FALSO (MENO DI 180GG)


SELECT 
    S.Sale_ID AS CodiceDocumento,
    S.SaleDate AS DataVendita,
    P.ProductName AS NomeProdotto,
    C.CategoryName AS Categoria,
    Co.CountryName AS Stato,
    R.RegionName AS Regione,
    DATEDIFF (CURRENT_DATE(), S.SaleDate) > 180 AS Oltre180Giorni
FROM Sales S
JOIN Product P ON S.Product_ID = P.Product_ID
JOIN Category C ON P.Category_ID = C.Category_ID
JOIN Country Co ON S.Country_ID = Co.Country_ID
JOIN Region R ON Co.Region_ID = R.Region_ID;


-- 3 - ELENCO DEI PRODOTTI CHE HANNO VENDUTO IN TOTALE UNA QUANTITA MAGGIORE CHE LA MEDIA - ANNO CENSITO


SELECT 
    s.Product_ID,
    SUM(s.Quantity * s.UnitPrice) AS FatturatoTotale
FROM Sales s
GROUP BY s.Product_ID
HAVING SUM(s.Quantity) > (
    SELECT AVG(t.Qnt_Tot)
    FROM (
        SELECT SUM(s2.Quantity) AS Qnt_Tot
        FROM Sales s2
        WHERE YEAR(s2.SaleDate) =  YEAR(CURRENT_DATE()) - 1  
        GROUP BY s2.Product_ID) AS t
);

SELECT *
FROM Sales;

-- 4 - ELENCO DEI PRODOTTI VENDUTI E FATTURATO PER ANNO

SELECT s.Product_ID, p.ProductName AS NomeProdotto,
	YEAR(s.SaleDate) as Anno, 
    SUM(s.Quantity * s.UnitPrice) AS FatturatoTotale
FROM Sales s
JOIN Product p 
ON p.Product_ID = s.Product_ID
GROUP BY YEAR(s.SaleDate), s.Product_ID;

-- 5 FATTURATO TOTALE PER PAESE PER ANNO, ORDINATO PER DATA E FATTURATO desc

SELECT c.Country_ID, c.CountryName,
	YEAR(s.SaleDate) as Anno, 
    SUM(s.Quantity * s.UnitPrice) AS FatturatoTotale
FROM Sales s
JOIN Country c
ON c.Country_ID = s.Country_ID
GROUP BY YEAR(s.SaleDate), c.Country_ID
ORDER BY YEAR(s.SaleDate) DESC, FatturatoTotale DESC;

SELECT c.Country_ID, c.CountryName,
	YEAR(s.SaleDate) as Anno, 
    SUM(s.Quantity * s.UnitPrice) AS FatturatoTotale  # questo ho lasciato ordinato di modo desc solo per il fatturato
FROM Sales s
JOIN Country c
ON c.Country_ID = s.Country_ID
GROUP BY YEAR(s.SaleDate), c.Country_ID
ORDER BY YEAR(s.SaleDate), FatturatoTotale DESC;

-- 6 - CATEGORIA PIU RICHIESTA - GAMES è STATA LA CATEGORIA PIU RICHIESTA IN QUESTO CONTESTO.

SELECT 
	CategoryName AS Categoria, 
    SUM(s.Quantity) AS Quantita
FROM Sales S
JOIN Product P ON S.Product_ID = P.Product_ID
JOIN Category C ON P.Category_ID = C.Category_ID  # questo mi fa vedere la quantita di vendita per categoria in generale
GROUP BY P.Category_ID
ORDER BY Quantita DESC;

SELECT 
	CategoryName AS Categoria, 
    SUM(s.Quantity) AS Quantita     # questo mi fa vedere solo il primo posto, visto che ho messo LIMIT 1, cosi vedo subito quale categoria ha avuto piu vendite
FROM Sales S
JOIN Product P ON S.Product_ID = P.Product_ID
JOIN Category C ON P.Category_ID = C.Category_ID 
GROUP BY P.Category_ID
ORDER BY Quantita DESC
LIMIT 1;

-- 7 - PRODOTTI INVENDUTI - BARBIE DOLL E L'UNICO PRODDOTO INVENDUTO

SELECT p.ProductName
FROM Product p
LEFT JOIN Sales s
ON p.Product_ID = s.Product_ID  # primo modo per verificare
WHERE s.Product_ID IS NULL;

SELECT p.ProductName
FROM Product p
WHERE p.Product_ID NOT IN (SELECT s.Product_ID FROM Sales s);   # secondo modo per verifficare


-- 8 - CREARE UNA VIEW - Anagrafe

CREATE OR REPLACE VIEW Anagrafe
AS 
SELECT 
	p.Product_ID AS Codice_Prodotto,
    p.ProductName AS Nome_Prodotto,
    c.CategoryName AS Nome_Categoria
	   
FROM Product p
JOIN Category c
ON p.Category_ID = C.Category_ID; 

SELECT *
FROM anagrafe;


-- 9 - VIEW - INFORMAZIONE GEOGRAFICHE


CREATE OR REPLACE VIEW Informazione_Geografiche
AS 
SELECT DISTINCT 
	p.Product_ID AS CodiceProdotto,
	p.ProductName AS NomeProdotto,
    c.CategoryName AS Categoria,
    co.CountryName AS Paese,
    r.RegionName AS Regione
FROM Sales s 
JOIN Product p
ON p.Product_ID = s.Product_ID
JOIN Category c
ON c.Category_ID = p.Category_ID
JOIN Country co
ON co.Country_ID = s.Country_ID
JOIN Region r
ON r.Region_ID = co.Region_ID;

SELECT *
FROM Informazione_Geografiche;